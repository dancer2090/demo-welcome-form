import QuestionForm from './component';

export default QuestionForm;