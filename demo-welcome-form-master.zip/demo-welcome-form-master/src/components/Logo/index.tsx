import Logo from './component';

export default Logo;