import React from 'react';
import QuestionForm from 'components/QuestionForm';

export default function Welcome(props : any) {
  return <QuestionForm {...props} />;
}