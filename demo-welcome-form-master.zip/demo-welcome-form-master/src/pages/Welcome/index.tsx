import Welcome from './component';

export default Welcome;