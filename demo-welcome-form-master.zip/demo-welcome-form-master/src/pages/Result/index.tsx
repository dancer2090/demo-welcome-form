import Result from './component';

export default Result;