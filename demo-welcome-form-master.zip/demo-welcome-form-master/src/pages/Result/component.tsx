import React from 'react';

const Result = () => {
  return (
    <div>
      result
    </div>
  )
}

export default Result;