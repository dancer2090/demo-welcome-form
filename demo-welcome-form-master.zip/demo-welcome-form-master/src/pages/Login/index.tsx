import Login from './component';

export default Login;